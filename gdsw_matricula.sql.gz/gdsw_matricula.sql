-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: gdsw_matricula
-- ------------------------------------------------------
-- Server version	5.5.46-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `curso`
--

DROP TABLE IF EXISTS `curso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curso` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `aulas_por_dia` int(11) DEFAULT NULL,
  `dias_por_semana` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curso`
--

LOCK TABLES `curso` WRITE;
/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
INSERT INTO `curso` VALUES (1,'Sistemas de Informação',4,5);
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dependencia`
--

DROP TABLE IF EXISTS `dependencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dependencia` (
  `disciplina_id` int(11) NOT NULL,
  `requisito_id` int(11) NOT NULL,
  PRIMARY KEY (`disciplina_id`,`requisito_id`),
  KEY `fk_requisito_idx` (`requisito_id`),
  KEY `fk_disciplina_idx` (`disciplina_id`),
  CONSTRAINT `fk_disciplinas_has_disciplinas1_disciplinas1` FOREIGN KEY (`disciplina_id`) REFERENCES `disciplina` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_disciplinas_has_disciplinas1_disciplinas2` FOREIGN KEY (`requisito_id`) REFERENCES `disciplina` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dependencia`
--

LOCK TABLES `dependencia` WRITE;
/*!40000 ALTER TABLE `dependencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `dependencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disciplina`
--

DROP TABLE IF EXISTS `disciplina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disciplina` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `periodo` int(11) DEFAULT NULL,
  `sigla` varchar(45) DEFAULT NULL,
  `ativa` tinyint(1) DEFAULT NULL,
  `curso_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_UNIQUE` (`nome`),
  UNIQUE KEY `sigla_UNIQUE` (`sigla`),
  KEY `fk_curso_idx` (`curso_id`),
  CONSTRAINT `fk_curso_id` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disciplina`
--

LOCK TABLES `disciplina` WRITE;
/*!40000 ALTER TABLE `disciplina` DISABLE KEYS */;
INSERT INTO `disciplina` VALUES (1,'ORGANIZAÇÃO DE EMPRESAS',1,'ORGE',1,1);
INSERT INTO `disciplina` VALUES (2,'ALGORITMOS E LÓGICA DE PROGRAMAÇÃO',1,'ALGO',1,1);
INSERT INTO `disciplina` VALUES (3,'INGLÊS INSTRUMENTAL',1,'INGL',1,1);
INSERT INTO `disciplina` VALUES (4,'CÁLCULO DIFERENCIAL E INTEGRAL',1,'CALC',1,1);
INSERT INTO `disciplina` VALUES (5,'PRINCÍPIOS DE SISTEMAS DE INFORMAÇÃO',1,'PRSI',1,1);
INSERT INTO `disciplina` VALUES (6,'ESTRUTURAS DE DADOS',2,'ESTD',1,1);
INSERT INTO `disciplina` VALUES (7,'ESTATÍSTICA E PROBABILIDADE',2,'ESTA',1,1);
INSERT INTO `disciplina` VALUES (8,'ARQUITETURA E ORGANIZAÇÃO DE COMPUTADORES',2,'ARQC',1,1);
INSERT INTO `disciplina` VALUES (9,'ARQUITETURA DE SISTEMAS OPERACIONAIS',2,'SOPE',1,1);
INSERT INTO `disciplina` VALUES (10,'FUNDAMENTOS DE BANCO DE DADOS',2,'FNBD',1,1);
INSERT INTO `disciplina` VALUES (11,'PROGRAMAÇÃO ORIENTADA A OBJETOS',3,'PROO',1,1);
INSERT INTO `disciplina` VALUES (12,'REDES DE COMPUTADORES',3,'RECO',1,1);
INSERT INTO `disciplina` VALUES (13,'ADMINISTRAÇÃO E PROJETO DE BANCO DE DADOS',3,'APBD',1,1);
INSERT INTO `disciplina` VALUES (14,'INTRODUÇÃO À ÁLGEBRA LINEAR',3,'IALI',1,1);
INSERT INTO `disciplina` VALUES (15,'FUNDAMENTOS DE PROGRAMAÇÃO INTERNET',3,'FPIN',1,1);
INSERT INTO `disciplina` VALUES (16,'ANÁLISE E PROJETO DE SISTEMAS',4,'APRS',1,1);
INSERT INTO `disciplina` VALUES (17,'RECURSOS HUMANOS E FINANCEIROS',4,'RHFI',1,1);
INSERT INTO `disciplina` VALUES (18,'PROGRAMAÇÃO AVANÇADA PARA INTERNET',4,'PAVI',1,1);
INSERT INTO `disciplina` VALUES (19,'METODOLOGIA DA PESQUISA CIENTÍFICA',4,'MEPC',1,1);
INSERT INTO `disciplina` VALUES (20,'LÓGICA MATEMÁTICA E MATEMÁTICA DISCRETA',4,'LMMD',1,1);
INSERT INTO `disciplina` VALUES (21,'PROJ. INTEGRADOR EM SISTEMAS DE INFORMAÇÃO I',5,'PROINT1',1,1);
INSERT INTO `disciplina` VALUES (22,'INTERFACE HUMANO-COMPUTADOR',5,'INHC',1,1);
INSERT INTO `disciplina` VALUES (23,'GERÊNCIA DE PROJETOS',5,'GEPJ',1,1);
INSERT INTO `disciplina` VALUES (24,'TÓPICOS AVANÇADOS EM BD',5,'TABD',1,1);
INSERT INTO `disciplina` VALUES (25,'GESTÃO DA SEGURANÇA DA INFORMAÇÃO',5,'GESINF',1,1);
INSERT INTO `disciplina` VALUES (26,'GERÊNCIA E DESENVOLVIMENTO DE SOFTWARE',6,'GDSW',1,1);
INSERT INTO `disciplina` VALUES (27,'INTRODUÇÃO A COMPILADORES',6,'INCO',1,1);
INSERT INTO `disciplina` VALUES (28,'PRINCÍPIOS DE MARKETING',6,'PRMK',1,1);
INSERT INTO `disciplina` VALUES (29,'SISTEMAS DE INFORMAÇÕES GERENCIAIS',6,'SIGE',1,1);
INSERT INTO `disciplina` VALUES (30,'LABORATÓRIO DE SISTEMAS OPERACIONAIS DE REDES',6,'LSOR',1,1);
INSERT INTO `disciplina` VALUES (31,'FILOSOFIA',6,'FILO',1,1);
INSERT INTO `disciplina` VALUES (32,'PROJETO INTEGRADOR EM SISTEMAS DE INFORMAÇÃO ',7,'PROINT2',1,1);
INSERT INTO `disciplina` VALUES (33,'SISTEMAS DE APOIO À DECISÃO',7,'SIAD',1,1);
INSERT INTO `disciplina` VALUES (34,'TÓPICOS ESPECIAIS EM SISTEMAS DE INFORMAÇÃO 1',7,'TESI1',1,1);
INSERT INTO `disciplina` VALUES (35,'INTELIGÊNCIA ARTIFICIAL',7,'INAR',1,1);
INSERT INTO `disciplina` VALUES (36,'COMPUTAÇÃO GRÁFICA',7,'COGR',1,1);
INSERT INTO `disciplina` VALUES (37,'SOCIOLOGIA',7,'SOCI',1,1);
INSERT INTO `disciplina` VALUES (38,'EMPREENDEDORISMO',8,'EMPR',1,1);
INSERT INTO `disciplina` VALUES (39,'TÓPICOS ESPECIAIS EM SISTEMAS DE INFORMAÇÃO 2',8,'TESI2',1,1);
INSERT INTO `disciplina` VALUES (40,'GOVERNANÇA EM TI',8,'GOTI',1,1);
INSERT INTO `disciplina` VALUES (41,'TRABALHO DE CONCLUSÃO DE CURSO',8,'TCC',1,1);
INSERT INTO `disciplina` VALUES (42,'ÉTICA',8,'ETIC',1,1);
INSERT INTO `disciplina` VALUES (43,'DIREITO E LEGISLAÇÃO',8,'DIRL',1,1);
INSERT INTO `disciplina` VALUES (44,'LIBRAS',8,'LIBR',1,1);
/*!40000 ALTER TABLE `disciplina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horario`
--

DROP TABLE IF EXISTS `horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horario` (
  `disciplina_id` int(11) NOT NULL,
  `aula` int(11) NOT NULL COMMENT 'Inteiro indicando a aula da semana, segundo o padrão do curso.',
  PRIMARY KEY (`disciplina_id`,`aula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horario`
--

LOCK TABLES `horario` WRITE;
/*!40000 ALTER TABLE `horario` DISABLE KEYS */;
INSERT INTO `horario` VALUES (1,2);
INSERT INTO `horario` VALUES (1,3);
INSERT INTO `horario` VALUES (1,6);
INSERT INTO `horario` VALUES (1,7);
INSERT INTO `horario` VALUES (2,4);
INSERT INTO `horario` VALUES (2,5);
INSERT INTO `horario` VALUES (2,12);
INSERT INTO `horario` VALUES (2,13);
INSERT INTO `horario` VALUES (3,8);
INSERT INTO `horario` VALUES (3,9);
INSERT INTO `horario` VALUES (3,18);
INSERT INTO `horario` VALUES (3,19);
INSERT INTO `horario` VALUES (4,14);
INSERT INTO `horario` VALUES (4,15);
INSERT INTO `horario` VALUES (4,16);
INSERT INTO `horario` VALUES (4,17);
INSERT INTO `horario` VALUES (5,0);
INSERT INTO `horario` VALUES (5,1);
INSERT INTO `horario` VALUES (5,10);
INSERT INTO `horario` VALUES (5,11);
INSERT INTO `horario` VALUES (6,4);
INSERT INTO `horario` VALUES (6,5);
INSERT INTO `horario` VALUES (6,12);
INSERT INTO `horario` VALUES (6,13);
INSERT INTO `horario` VALUES (7,10);
INSERT INTO `horario` VALUES (7,11);
INSERT INTO `horario` VALUES (7,14);
INSERT INTO `horario` VALUES (7,15);
INSERT INTO `horario` VALUES (8,16);
INSERT INTO `horario` VALUES (8,17);
INSERT INTO `horario` VALUES (8,18);
INSERT INTO `horario` VALUES (8,19);
INSERT INTO `horario` VALUES (9,0);
INSERT INTO `horario` VALUES (9,1);
INSERT INTO `horario` VALUES (9,8);
INSERT INTO `horario` VALUES (9,9);
INSERT INTO `horario` VALUES (10,2);
INSERT INTO `horario` VALUES (10,3);
INSERT INTO `horario` VALUES (10,6);
INSERT INTO `horario` VALUES (10,7);
INSERT INTO `horario` VALUES (11,4);
INSERT INTO `horario` VALUES (11,5);
INSERT INTO `horario` VALUES (11,12);
INSERT INTO `horario` VALUES (11,13);
INSERT INTO `horario` VALUES (12,6);
INSERT INTO `horario` VALUES (12,7);
INSERT INTO `horario` VALUES (12,18);
INSERT INTO `horario` VALUES (12,19);
INSERT INTO `horario` VALUES (13,2);
INSERT INTO `horario` VALUES (13,3);
INSERT INTO `horario` VALUES (13,16);
INSERT INTO `horario` VALUES (13,17);
INSERT INTO `horario` VALUES (14,8);
INSERT INTO `horario` VALUES (14,9);
INSERT INTO `horario` VALUES (14,14);
INSERT INTO `horario` VALUES (14,15);
INSERT INTO `horario` VALUES (15,0);
INSERT INTO `horario` VALUES (15,1);
INSERT INTO `horario` VALUES (15,10);
INSERT INTO `horario` VALUES (15,11);
INSERT INTO `horario` VALUES (16,6);
INSERT INTO `horario` VALUES (16,7);
INSERT INTO `horario` VALUES (16,8);
INSERT INTO `horario` VALUES (16,9);
INSERT INTO `horario` VALUES (17,0);
INSERT INTO `horario` VALUES (17,1);
INSERT INTO `horario` VALUES (17,12);
INSERT INTO `horario` VALUES (17,13);
INSERT INTO `horario` VALUES (18,2);
INSERT INTO `horario` VALUES (18,3);
INSERT INTO `horario` VALUES (18,18);
INSERT INTO `horario` VALUES (18,19);
INSERT INTO `horario` VALUES (19,4);
INSERT INTO `horario` VALUES (19,5);
INSERT INTO `horario` VALUES (19,10);
INSERT INTO `horario` VALUES (19,11);
INSERT INTO `horario` VALUES (20,14);
INSERT INTO `horario` VALUES (20,15);
INSERT INTO `horario` VALUES (20,16);
INSERT INTO `horario` VALUES (20,17);
INSERT INTO `horario` VALUES (21,0);
INSERT INTO `horario` VALUES (21,1);
INSERT INTO `horario` VALUES (21,12);
INSERT INTO `horario` VALUES (21,13);
INSERT INTO `horario` VALUES (22,6);
INSERT INTO `horario` VALUES (22,7);
INSERT INTO `horario` VALUES (22,12);
INSERT INTO `horario` VALUES (22,13);
INSERT INTO `horario` VALUES (23,2);
INSERT INTO `horario` VALUES (23,3);
INSERT INTO `horario` VALUES (23,8);
INSERT INTO `horario` VALUES (23,9);
INSERT INTO `horario` VALUES (24,10);
INSERT INTO `horario` VALUES (24,11);
INSERT INTO `horario` VALUES (24,18);
INSERT INTO `horario` VALUES (24,19);
INSERT INTO `horario` VALUES (25,4);
INSERT INTO `horario` VALUES (25,5);
INSERT INTO `horario` VALUES (25,16);
INSERT INTO `horario` VALUES (25,17);
INSERT INTO `horario` VALUES (26,4);
INSERT INTO `horario` VALUES (26,5);
INSERT INTO `horario` VALUES (26,14);
INSERT INTO `horario` VALUES (26,15);
INSERT INTO `horario` VALUES (27,6);
INSERT INTO `horario` VALUES (27,7);
INSERT INTO `horario` VALUES (27,18);
INSERT INTO `horario` VALUES (27,19);
INSERT INTO `horario` VALUES (28,0);
INSERT INTO `horario` VALUES (28,1);
INSERT INTO `horario` VALUES (28,12);
INSERT INTO `horario` VALUES (28,13);
INSERT INTO `horario` VALUES (29,8);
INSERT INTO `horario` VALUES (29,9);
INSERT INTO `horario` VALUES (29,16);
INSERT INTO `horario` VALUES (29,17);
INSERT INTO `horario` VALUES (30,2);
INSERT INTO `horario` VALUES (30,3);
INSERT INTO `horario` VALUES (30,10);
INSERT INTO `horario` VALUES (30,11);
INSERT INTO `horario` VALUES (31,4);
INSERT INTO `horario` VALUES (31,5);
INSERT INTO `horario` VALUES (31,8);
INSERT INTO `horario` VALUES (31,9);
INSERT INTO `horario` VALUES (32,2);
INSERT INTO `horario` VALUES (32,3);
INSERT INTO `horario` VALUES (32,12);
INSERT INTO `horario` VALUES (32,13);
INSERT INTO `horario` VALUES (33,0);
INSERT INTO `horario` VALUES (33,1);
INSERT INTO `horario` VALUES (33,18);
INSERT INTO `horario` VALUES (33,19);
INSERT INTO `horario` VALUES (34,8);
INSERT INTO `horario` VALUES (34,9);
INSERT INTO `horario` VALUES (34,10);
INSERT INTO `horario` VALUES (34,11);
INSERT INTO `horario` VALUES (35,14);
INSERT INTO `horario` VALUES (35,15);
INSERT INTO `horario` VALUES (35,16);
INSERT INTO `horario` VALUES (35,17);
INSERT INTO `horario` VALUES (37,6);
INSERT INTO `horario` VALUES (37,7);
INSERT INTO `horario` VALUES (37,16);
INSERT INTO `horario` VALUES (37,17);
INSERT INTO `horario` VALUES (38,0);
INSERT INTO `horario` VALUES (38,1);
INSERT INTO `horario` VALUES (38,10);
INSERT INTO `horario` VALUES (38,11);
INSERT INTO `horario` VALUES (39,2);
INSERT INTO `horario` VALUES (39,3);
INSERT INTO `horario` VALUES (39,14);
INSERT INTO `horario` VALUES (39,15);
INSERT INTO `horario` VALUES (40,12);
INSERT INTO `horario` VALUES (40,13);
INSERT INTO `horario` VALUES (40,18);
INSERT INTO `horario` VALUES (40,19);
INSERT INTO `horario` VALUES (43,4);
INSERT INTO `horario` VALUES (43,5);
INSERT INTO `horario` VALUES (44,6);
INSERT INTO `horario` VALUES (44,7);
/*!40000 ALTER TABLE `horario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-06 13:33:42
